#!/system/bin/sh

apt update && apt upgrade 
pkg i play-audio python -y
pip install colorama 
pip install art 
pip install datetime
pip install time
pip install imghdr
pip install email 
echo '

        |*+==================+*|
              installed !    
    for runnning -> " wish.sh <option> 'name'"'
